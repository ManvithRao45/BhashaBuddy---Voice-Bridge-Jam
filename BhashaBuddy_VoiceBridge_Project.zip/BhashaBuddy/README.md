# BhashaBuddy – VoiceBridge

A bilingual/multilingual technical English learning app built with React + Vite.

## Run on Windows
1. Install Node.js LTS from https://nodejs.org/ (if not already installed).
2. Extract this ZIP.
3. Open the extracted `BhashaBuddy` folder in VS Code.
4. In VS Code choose Terminal > New Terminal.
5. Run: `npm install`
6. Run: `npm run dev`
7. Open the Local URL printed in the terminal (usually http://localhost:5173).

## Features included
- English, Telugu, Hindi and Tamil interface language selection
- 50 technical vocabulary records with phonetic guide, Telugu/Hindi/Tamil meanings, example and difficulty tier
- Searchable and level-filtered flashcards
- Browser speech synthesis for words and example sentences
- Browser speech recognition with Levenshtein-based similarity scoring
- Text-based pronunciation fallback if speech recognition is unavailable
- Five-question multiple-choice daily quiz
- Daily goal, completed words, streak and localStorage persistence
- Responsive mobile-first layout

## Important testing notes
- Use Google Chrome or Microsoft Edge for best Web Speech API support.
- Run on `localhost` (Vite does this) and allow microphone permission.
- Speech recognition availability depends on browser/device and may need internet access.
- If recognition is unavailable, use the text fallback in the pronunciation panel.
- Progress is stored in this browser on this device. Clearing browser storage resets it.

## Demo script
1. Start app and select Telugu.
2. Open Learn and show the word Algorithm, Telugu meaning and phonetic guide.
3. Press Listen to hear the English word.
4. Press Speak, allow microphone, and say “Algorithm”.
5. Show pronunciation match score.
6. Mark/advance a flashcard and show daily goal progress.
7. Open Daily quiz and answer a question.
8. Open My progress and show saved completed words and streak.

## Project structure
- `src/App.jsx` – UI, navigation, speech APIs, quiz, progress logic
- `src/words.js` – 50-word vocabulary dataset
- `src/style.css` – responsive styling
- `src/main.jsx` – React entry point
- `index.html` – page entry point

## Scope note
This hackathon prototype uses browser localStorage rather than a server database, so progress is local to the current browser/device. The conversational chatbot, offline audio cache/service worker and peer challenge are stretch features and are not included in this one-hour MVP.
