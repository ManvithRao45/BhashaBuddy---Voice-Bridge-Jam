export const words = [
  {
    "id": 1,
    "term": "Algorithm",
    "phonetic": "AL-guh-rith-um",
    "te": "క్రమసూత్రం",
    "hi": "कलन विधि",
    "ta": "வழிமுறை",
    "sentence": "An algorithm is a step-by-step method to solve a problem.",
    "level": "Beginner"
  },
  {
    "id": 2,
    "term": "Variable",
    "phonetic": "VAIR-ee-uh-bul",
    "te": "చరరాశి",
    "hi": "चर",
    "ta": "மாறி",
    "sentence": "A variable stores a value in a program.",
    "level": "Beginner"
  },
  {
    "id": 3,
    "term": "Function",
    "phonetic": "FUNK-shun",
    "te": "ఫంక్షన్ / ప్రమేయం",
    "hi": "फलन",
    "ta": "செயல்பாடு",
    "sentence": "A function performs a specific task in a program.",
    "level": "Beginner"
  },
  {
    "id": 4,
    "term": "Database",
    "phonetic": "DAY-tuh-bays",
    "te": "డేటాబేస్",
    "hi": "डेटाबेस",
    "ta": "தரவுத்தளம்",
    "sentence": "The database stores student records.",
    "level": "Beginner"
  },
  {
    "id": 5,
    "term": "Network",
    "phonetic": "NET-wurk",
    "te": "నెట్‌వర్క్",
    "hi": "नेटवर्क",
    "ta": "வலையமைப்பு",
    "sentence": "A computer network connects multiple devices.",
    "level": "Beginner"
  },
  {
    "id": 6,
    "term": "Software",
    "phonetic": "SOFT-wair",
    "te": "సాఫ్ట్‌వేర్",
    "hi": "सॉफ़्टवेयर",
    "ta": "மென்பொருள்",
    "sentence": "Software gives instructions to a computer.",
    "level": "Beginner"
  },
  {
    "id": 7,
    "term": "Hardware",
    "phonetic": "HARD-wair",
    "te": "హార్డ్‌వేర్",
    "hi": "हार्डवेयर",
    "ta": "வன்பொருள்",
    "sentence": "The keyboard is a hardware component.",
    "level": "Beginner"
  },
  {
    "id": 8,
    "term": "Compiler",
    "phonetic": "kum-PY-ler",
    "te": "కంపైలర్",
    "hi": "कम्पाइलर",
    "ta": "தொகுப்பி",
    "sentence": "A compiler translates source code into machine code.",
    "level": "Beginner"
  },
  {
    "id": 9,
    "term": "Array",
    "phonetic": "uh-RAY",
    "te": "శ్రేణి",
    "hi": "सरणी",
    "ta": "வரிசை",
    "sentence": "An array stores multiple values of the same type.",
    "level": "Beginner"
  },
  {
    "id": 10,
    "term": "Loop",
    "phonetic": "LOOP",
    "te": "పునరావృత చక్రం",
    "hi": "लूप / पुनरावृत्ति",
    "ta": "சுழற்சி",
    "sentence": "A loop repeats a block of instructions.",
    "level": "Beginner"
  },
  {
    "id": 11,
    "term": "Operating System",
    "phonetic": "OP-uh-ray-ting SIS-tum",
    "te": "ఆపరేటింగ్ సిస్టమ్",
    "hi": "प्रचालन तंत्र",
    "ta": "இயக்க முறைமை",
    "sentence": "An operating system manages computer resources.",
    "level": "Beginner"
  },
  {
    "id": 12,
    "term": "Input",
    "phonetic": "IN-put",
    "te": "ఇన్‌పుట్",
    "hi": "इनपुट",
    "ta": "உள்ளீடு",
    "sentence": "The keyboard is used to provide input.",
    "level": "Beginner"
  },
  {
    "id": 13,
    "term": "Output",
    "phonetic": "OUT-put",
    "te": "అవుట్‌పుట్",
    "hi": "आउटपुट",
    "ta": "வெளியீடு",
    "sentence": "The monitor displays the output.",
    "level": "Beginner"
  },
  {
    "id": 14,
    "term": "Debugging",
    "phonetic": "dee-BUG-ing",
    "te": "లోపాల గుర్తింపు",
    "hi": "डिबगिंग",
    "ta": "பிழைத்திருத்தம்",
    "sentence": "Debugging helps find and fix errors in code.",
    "level": "Intermediate"
  },
  {
    "id": 15,
    "term": "Syntax",
    "phonetic": "SIN-taks",
    "te": "వ్యాకరణ నిర్మాణం",
    "hi": "वाक्य-विन्यास",
    "ta": "தொடரியல்",
    "sentence": "Correct syntax is required for valid code.",
    "level": "Intermediate"
  },
  {
    "id": 16,
    "term": "Encryption",
    "phonetic": "en-KRIP-shun",
    "te": "గుప్తీకరణ",
    "hi": "कूटलेखन",
    "ta": "குறியாக்கம்",
    "sentence": "Encryption protects information from unauthorized access.",
    "level": "Intermediate"
  },
  {
    "id": 17,
    "term": "Artificial Intelligence",
    "phonetic": "ar-tuh-FISH-ul in-TEL-i-jens",
    "te": "కృత్రిమ మేధస్సు",
    "hi": "कृत्रिम बुद्धिमत्ता",
    "ta": "செயற்கை நுண்ணறிவு",
    "sentence": "Artificial intelligence enables machines to perform smart tasks.",
    "level": "Intermediate"
  },
  {
    "id": 18,
    "term": "Machine Learning",
    "phonetic": "muh-SHEEN LUR-ning",
    "te": "యంత్ర అభ్యాసం",
    "hi": "मशीन लर्निंग",
    "ta": "இயந்திரக் கற்றல்",
    "sentence": "Machine learning helps computers learn from data.",
    "level": "Intermediate"
  },
  {
    "id": 19,
    "term": "Data Structure",
    "phonetic": "DAY-tuh STRUK-cher",
    "te": "డేటా నిర్మాణం",
    "hi": "डेटा संरचना",
    "ta": "தரவு கட்டமைப்பு",
    "sentence": "A data structure organizes information efficiently.",
    "level": "Intermediate"
  },
  {
    "id": 20,
    "term": "Cloud Computing",
    "phonetic": "KLOUD kum-PYOO-ting",
    "te": "క్లౌడ్ కంప్యూటింగ్",
    "hi": "क्लाउड कंप्यूटिंग",
    "ta": "மேகக் கணினி",
    "sentence": "Cloud computing provides computing services over the internet.",
    "level": "Intermediate"
  },
  {
    "id": 21,
    "term": "API",
    "phonetic": "AY-pee-EYE",
    "te": "అప్లికేషన్ ప్రోగ్రామింగ్ ఇంటర్‌ఫేస్",
    "hi": "एपीआई",
    "ta": "பயன்பாட்டு நிரலாக்க இடைமுகம்",
    "sentence": "An API allows two applications to communicate.",
    "level": "Intermediate"
  },
  {
    "id": 22,
    "term": "Frontend",
    "phonetic": "FRUNT-end",
    "te": "ఫ్రంట్‌ఎండ్",
    "hi": "फ्रंटएंड",
    "ta": "முன்புறம்",
    "sentence": "Frontend development focuses on the user interface.",
    "level": "Beginner"
  },
  {
    "id": 23,
    "term": "Backend",
    "phonetic": "BAK-end",
    "te": "బ్యాక్‌ఎండ్",
    "hi": "बैकएंड",
    "ta": "பின்புறம்",
    "sentence": "The backend handles application logic and data.",
    "level": "Beginner"
  },
  {
    "id": 24,
    "term": "Server",
    "phonetic": "SUR-ver",
    "te": "సర్వర్",
    "hi": "सर्वर",
    "ta": "சேவையகம்",
    "sentence": "A server provides services to client devices.",
    "level": "Beginner"
  },
  {
    "id": 25,
    "term": "Client",
    "phonetic": "KLY-ent",
    "te": "క్లయింట్",
    "hi": "क्लाइंट",
    "ta": "வாடிக்கையாளர் சாதனம்",
    "sentence": "A client requests data from a server.",
    "level": "Beginner"
  },
  {
    "id": 26,
    "term": "Protocol",
    "phonetic": "PROH-tuh-kol",
    "te": "ప్రోటోకాల్",
    "hi": "प्रोटोकॉल",
    "ta": "நெறிமுறை",
    "sentence": "HTTP is a protocol used on the web.",
    "level": "Intermediate"
  },
  {
    "id": 27,
    "term": "Bandwidth",
    "phonetic": "BAND-width",
    "te": "బ్యాండ్‌విడ్త్",
    "hi": "बैंडविड्थ",
    "ta": "அலைவரிசை",
    "sentence": "Bandwidth measures data transfer capacity.",
    "level": "Intermediate"
  },
  {
    "id": 28,
    "term": "Cybersecurity",
    "phonetic": "SY-ber-si-KYUR-i-tee",
    "te": "సైబర్ భద్రత",
    "hi": "साइबर सुरक्षा",
    "ta": "இணையப் பாதுகாப்பு",
    "sentence": "Cybersecurity protects systems and networks.",
    "level": "Intermediate"
  },
  {
    "id": 29,
    "term": "Authentication",
    "phonetic": "aw-then-ti-KAY-shun",
    "te": "ధృవీకరణ",
    "hi": "प्रमाणीकरण",
    "ta": "அங்கீகாரம்",
    "sentence": "Authentication verifies a user's identity.",
    "level": "Intermediate"
  },
  {
    "id": 30,
    "term": "Optimization",
    "phonetic": "op-tuh-muh-ZAY-shun",
    "te": "ఆప్టిమైజేషన్",
    "hi": "अनुकूलन",
    "ta": "மேம்படுத்தல்",
    "sentence": "Optimization improves program performance.",
    "level": "Intermediate"
  },
  {
    "id": 31,
    "term": "Iteration",
    "phonetic": "it-uh-RAY-shun",
    "te": "పునరావృతం",
    "hi": "पुनरावृत्ति",
    "ta": "மறுசெயல்",
    "sentence": "Each iteration repeats a process once.",
    "level": "Intermediate"
  },
  {
    "id": 32,
    "term": "Parameter",
    "phonetic": "puh-RAM-uh-ter",
    "te": "పరామితి",
    "hi": "प्राचल",
    "ta": "அளவுரு",
    "sentence": "A parameter is an input accepted by a function.",
    "level": "Intermediate"
  },
  {
    "id": 33,
    "term": "Debug",
    "phonetic": "dee-BUG",
    "te": "లోపాన్ని సరిచేయు",
    "hi": "त्रुटि दूर करना",
    "ta": "பிழையை நீக்கு",
    "sentence": "We debug the program to remove errors.",
    "level": "Beginner"
  },
  {
    "id": 34,
    "term": "Interface",
    "phonetic": "IN-ter-fays",
    "te": "ఇంటర్‌ఫేస్",
    "hi": "इंटरफ़ेस",
    "ta": "இடைமுகம்",
    "sentence": "The interface helps users interact with software.",
    "level": "Beginner"
  },
  {
    "id": 35,
    "term": "Simulation",
    "phonetic": "sim-yuh-LAY-shun",
    "te": "అనుకరణ",
    "hi": "अनुकरण",
    "ta": "உருவகப்படுத்தல்",
    "sentence": "A simulation models a real-world process.",
    "level": "Intermediate"
  },
  {
    "id": 36,
    "term": "Sensor",
    "phonetic": "SEN-ser",
    "te": "సెన్సార్",
    "hi": "संवेदक",
    "ta": "உணரி",
    "sentence": "A sensor detects changes in the environment.",
    "level": "Beginner"
  },
  {
    "id": 37,
    "term": "Microcontroller",
    "phonetic": "MY-kroh-kun-TROH-ler",
    "te": "మైక్రోకంట్రోలర్",
    "hi": "माइक्रोकंट्रोलर",
    "ta": "நுண்கட்டுப்படுத்தி",
    "sentence": "A microcontroller controls an embedded system.",
    "level": "Intermediate"
  },
  {
    "id": 38,
    "term": "Circuit",
    "phonetic": "SUR-kit",
    "te": "విద్యుత్ వలయం",
    "hi": "परिपथ",
    "ta": "மின்சுற்று",
    "sentence": "A circuit provides a path for electric current.",
    "level": "Beginner"
  },
  {
    "id": 39,
    "term": "Voltage",
    "phonetic": "VOHL-tij",
    "te": "వోల్టేజ్",
    "hi": "वोल्टता",
    "ta": "மின்னழுத்தம்",
    "sentence": "Voltage is the electrical potential difference.",
    "level": "Beginner"
  },
  {
    "id": 40,
    "term": "Current",
    "phonetic": "KUR-ent",
    "te": "విద్యుత్ ప్రవాహం",
    "hi": "विद्युत धारा",
    "ta": "மின்னோட்டம்",
    "sentence": "Electric current is the flow of electric charge.",
    "level": "Beginner"
  },
  {
    "id": 41,
    "term": "Resistance",
    "phonetic": "ri-ZIS-tuns",
    "te": "నిరోధం",
    "hi": "प्रतिरोध",
    "ta": "மின்தடை",
    "sentence": "Resistance opposes the flow of electric current.",
    "level": "Beginner"
  },
  {
    "id": 42,
    "term": "Frequency",
    "phonetic": "FREE-kwen-see",
    "te": "పౌనఃపున్యం",
    "hi": "आवृत्ति",
    "ta": "அதிர்வெண்",
    "sentence": "Frequency is the number of cycles per second.",
    "level": "Intermediate"
  },
  {
    "id": 43,
    "term": "Wavelength",
    "phonetic": "WAYV-length",
    "te": "తరంగదైర్ఘ్యం",
    "hi": "तरंगदैर्ध्य",
    "ta": "அலைநீளம்",
    "sentence": "Wavelength is the distance between repeating wave points.",
    "level": "Intermediate"
  },
  {
    "id": 44,
    "term": "Energy",
    "phonetic": "EN-er-jee",
    "te": "శక్తి",
    "hi": "ऊर्जा",
    "ta": "ஆற்றல்",
    "sentence": "Energy is the capacity to do work.",
    "level": "Beginner"
  },
  {
    "id": 45,
    "term": "Momentum",
    "phonetic": "moh-MEN-tum",
    "te": "ద్రవ్యవేగం",
    "hi": "संवेग",
    "ta": "உந்தம்",
    "sentence": "Momentum is the product of mass and velocity.",
    "level": "Intermediate"
  },
  {
    "id": 46,
    "term": "Force",
    "phonetic": "FORS",
    "te": "బలం",
    "hi": "बल",
    "ta": "விசை",
    "sentence": "Force can change an object's motion.",
    "level": "Beginner"
  },
  {
    "id": 47,
    "term": "Acceleration",
    "phonetic": "ak-sel-uh-RAY-shun",
    "te": "త్వరణం",
    "hi": "त्वरण",
    "ta": "முடுக்கம்",
    "sentence": "Acceleration is the rate of change of velocity.",
    "level": "Intermediate"
  },
  {
    "id": 48,
    "term": "Density",
    "phonetic": "DEN-si-tee",
    "te": "సాంద్రత",
    "hi": "घनत्व",
    "ta": "அடர்த்தி",
    "sentence": "Density is mass per unit volume.",
    "level": "Beginner"
  },
  {
    "id": 49,
    "term": "Thermodynamics",
    "phonetic": "thur-moh-dy-NAM-iks",
    "te": "ఉష్ణగతిక శాస్త్రం",
    "hi": "ऊष्मागतिकी",
    "ta": "வெப்ப இயக்கவியல்",
    "sentence": "Thermodynamics studies heat, work and energy.",
    "level": "Advanced"
  },
  {
    "id": 50,
    "term": "Sustainability",
    "phonetic": "suh-stayn-uh-BIL-i-tee",
    "te": "సుస్థిరత",
    "hi": "सततता",
    "ta": "நிலைத்தன்மை",
    "sentence": "Sustainability means using resources responsibly.",
    "level": "Intermediate"
  }
];
